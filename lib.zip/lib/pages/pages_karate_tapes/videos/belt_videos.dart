class BeltVideos {
  static final Map<String, Map<String, String>> allVideos = {
    'blanca': {'video1': 'Iql92tNge5E'},
    'amarilla': {'video1': 'kHER2vaAX0Q'},
    'naranja': {'video1': 'rbWEwVwXm2M'},
    'verde': {'video1': 'GY_m3CDHm_o'},
    'azul': {'video1': 'GY_m3CDHm_o'},
    'morado': {'video1': 'H3is0X_-FF4'},
    'cafe': {'video1': 'GY_m3CDHm_o'},
    'negra': {'video1': 'GY_m3CDHm_o'},
  };
}
